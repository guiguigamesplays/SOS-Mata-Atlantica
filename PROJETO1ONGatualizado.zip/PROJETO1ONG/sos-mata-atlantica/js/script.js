document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const menu = document.querySelector(".nav");
  if (toggle && menu) {
    toggle.addEventListener("click", () => {
      const open = menu.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
      toggle.textContent = open ? "✕" : "☰";
    });
    menu.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      menu.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Abrir menu");
      toggle.textContent = "☰";
    }));
  }

  const form = document.getElementById("cadastro-form");
  if (form) {
    const feedback = document.getElementById("form-feedback");
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const nome = document.getElementById("nome").value.trim();
      feedback.textContent = `Obrigado, ${nome}! Seu cadastro demonstrativo foi validado neste navegador. Nenhum dado foi enviado ou armazenado.`;
      feedback.classList.add("visible");
      feedback.focus();
      form.reset();
    });
    form.addEventListener("reset", () => {
      feedback.textContent = "";
      feedback.classList.remove("visible");
    });
  }
});